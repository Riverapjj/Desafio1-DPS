import * as React from 'react';
import { Text, View, StyleSheet, ScrollView, FlatList, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

const HelloWorldApp = () => {
  return (
    <ScrollView style={styles.header}>
      <View>
        <FlatList
        data={[
          {
            name: 'Mercurio',
            description: 'Planeta más próximo al Sol',
            img: require("./assets/img/mercurio.jpg")
          },
          {
            name: 'Venus',
            description: 'Segundo planeta más próximo al Sol',
            img: require("./assets/img/venus.jpg")
          },
          {
            name: 'La Tierra',
            description: 'Tercer planeta más cercano al Sol',
            img: require("./assets/img/tierra.jpg")
          },
          {
            name: 'Marte',
            description: 'Cuarto planeta más cercano al Sol',
            img: require("./assets/img/marte.jpg")
          },
          {
            name: 'Estación Espacial Internacional',
            description: 'Situada en la órbita terrestre baja',
            img: require("./assets/img/estacion.jpg")
          },
          {
            name: 'Luna',
            description: 'Único satélite natural de la Tierra',
            img: require("./assets/img/luna.webp")
          },
          {
            name: 'Ceres',
            description: 'Planeta enano situado entre Marte y Júpiter',
            img: require("./assets/img/ceres.jpg")
          },
          {
            name: 'Ío',
            description: 'El más interior de los satélites galileanos de Júpiter',
            img: require("./assets/img/io.jpg")
          },
          {
            name: 'Europa',
            description: 'El más pequeño de los satélites galileanos de Jupiter',
            img: require("./assets/img/europa.jpg")
          }
        ]}


        renderItem={({item}) => 
        
        <View style={styles.container}>
          <Image style={styles.image} source={item.img}/>
          <View>
            <Text style={styles.item_name}>{item.name}</Text>
            <Text style={styles.item_description}>{item.description}</Text>
          </View>
        </View>
        
        }
      />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: 40,
    flex: 1
  },
  container: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 0.5,
    borderBottomColor: "gray"
  },
  item_name: {
    paddingLeft: 10,
    fontSize: 17,
    fontWeight: "bold"
  },
  item_description: {
    paddingLeft: 10,
    fontSize: 11,
    flexWrap: "wrap"
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 50,
    overflow: "hidden"
    }
});

export default HelloWorldApp;