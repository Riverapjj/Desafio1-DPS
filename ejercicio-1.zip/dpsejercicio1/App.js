import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, Alert , FlatList} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { InputNumber } from 'antd';

const data = [
  { label: 'Manzana', value: '1', price: 0.5 },
  { label: 'Naranja', value: '2', price: 0.25 },
  { label: 'Pera', value: '3', price: 0.6 },
  { label: 'Uvas', value: '4', price: 1.25 },
  { label: 'Kiwis', value: '5', price: 0.8 },
  { label: 'Chile', value: '6', price: 0.25 },
  { label: 'Leche', value: '7', price: 1.25 },
  { label: 'Cereal', value: '8', price: 2.5 },
];

const DropdownComponent = () => {
  const [value, setValue] = useState(null);
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);
  const [isFocus, setIsFocus] = useState(false);

  const btnClick = () => {
    const filtered = cart.filter(obj => {
      return obj.name === value.label;
    });
    if(filtered.length>0){
      filtered[0].quantity+=1;
      setCart(cart);
    }else{
      setCart([...cart, {name:value.label,price:value.price,quantity:1}]); 
    }
    calcTotal();
  };

  const calcTotal = () => {
    let aux = 0;
    for (let i = 0; i<cart.length; i++){
      aux+=(cart[i].price*cart[i].quantity); 
    }
    setTotal(aux);
  }

  const addQua = (item) => {

  }
  const remQua = (item) => {
    
  }
  const onChange = (value,index) => {
    console.log('changed', value, index); 
  };
  
  return (
    <View style={styles.container}>
      <Dropdown
        style={[styles.dropdown, isFocus && { borderColor: 'blue' }]} 
        data={data}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder={!isFocus ? 'Select item' : '...'}
        value={value}
        onFocus={() => setIsFocus(true)}
        onBlur={() => setIsFocus(false)}
        onChange={(item) => {
          setValue(item);
          setIsFocus(false);
        }}
        renderLeftIcon={() => (
          <AntDesign
            style={styles.icon}
            color={isFocus ? 'blue' : 'black'}
            name="Safety"
            size={20}
          />
        )}
      />
      <Button onPress={btnClick} title="Add to cart" color="#841584" />
      <FlatList
        data={cart}
        renderItem={({item,index}) =>         
        <View>
          <View>
            <Text>{item.name}</Text>
            <Text>{item.price}</Text>
            <InputNumber min={0} max={10} defaultValue={item.quantity} onChange={onChange(value,index)} /> 
          </View>
        </View>
        }
      />
      <Text>{total}</Text>
    </View>
  );
};

export default DropdownComponent;

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    padding: 16,
  },
  dropdown: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 0.5,
    borderRadius: 8,
    paddingHorizontal: 8,
    marginTop: 100,
  },
  icon: {
    marginRight: 5,
  },
  label: {
    position: 'absolute',
    backgroundColor: 'white',
    left: 22,
    top: 8,
    zIndex: 999,
    paddingHorizontal: 8,
    fontSize: 14,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
});
