import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, TouchableOpacity, FlatList} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { InputNumber } from 'antd';

const data = [
  { label: 'Manzana', value: '1', price: 0.5 },
  { label: 'Naranja', value: '2', price: 0.25 },
  { label: 'Pera', value: '3', price: 0.6 },
  { label: 'Uvas', value: '4', price: 1.25 },
  { label: 'Kiwis', value: '5', price: 0.8 },
  { label: 'Chile', value: '6', price: 0.25 },
  { label: 'Leche', value: '7', price: 1.25 },
  { label: 'Cereal', value: '8', price: 2.5 },
];

const DropdownComponent = () => {
  const [value, setValue] = useState(null);
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);
  const [isFocus, setIsFocus] = useState(false);

  const btnClick = () => {    
    const filtered = cart.filter(obj => {
      return obj.name === value.label;
    });
    if(filtered.length>0){
      filtered[0].quantity+=1;
      setCart([...cart]);
    }else{
      setCart([...cart, {name:value.label,price:value.price,quantity:1}]); 
    }
    calcTotal();
    setIsFocus(false);
    setValue(null);
  };

  const calcTotal = () => {
    let aux = 0;
    for (let i = 0; i<cart.length; i++){
      aux+=(cart[i].price*cart[i].quantity); 
    }
    setTotal(aux.toFixed(2));
  }
  const changeQua = (value,index) => {
    if(value!==0){
      cart[index].quantity=value;
      setCart([...cart]);
      calcTotal();
    }else{
      remItem(index);
    }
  };
  const remItem = (index) => {
    const newCart = [...cart];
    newCart.splice(index,1);
    setCart([...newCart]);
    calcTotal();
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.containerTop}>
        <Dropdown
          style={[styles.dropdown, isFocus && { borderColor: 'blue' }]}
          data={data}
          maxHeight={300}
          labelField="label"
          valueField="value"
          placeholder={!isFocus ? 'Select item' : '...'}
          value={value}
          onFocus={() => setIsFocus(true)}
          onBlur={() => setIsFocus(false)}
          onChange={(item) => {
            setValue(item);
            setIsFocus(false);
          }}
          renderLeftIcon={() => (
            <AntDesign
              style={styles.icon}
              color={isFocus ? 'blue' : 'black'}
              name="Safety"
              size={20}
            />
          )}
        />
        <View style={styles.containerBtn}>
          <TouchableOpacity onPress={btnClick} style={styles.btn}>
            <Text style={styles.btnTitle}>Add to cart</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View>
        <FlatList
          data={cart}
          renderItem={({item,index}) =>         
          <View>
            <View style={styles.containerTable}>
              <Text style={styles.txtName}>{item.name}</Text>
              <Text style={styles.txtPrice}>{item.price}</Text>
              <View style={styles.number}><InputNumber min={0} max={10} defaultValue={item.quantity} index={index} onChange={(value) => changeQua(value,index)}/></View>
              <AntDesign style={styles.close} color={isFocus ? 'blue' : 'black'} name="closesquare" size={20} onPress={(index) => remItem(index)}/>
            </View>
          </View>
          }
        />
        <View style={styles.totalView}>
          <Text style={styles.totalViewText}>Total: {total}</Text>
        </View>
      </View>
    </View>
  );
};

export default DropdownComponent;

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    marginHorizontal: 'auto',
    padding: 16,
    width: 600,
  },
  dropdown: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 0.5,
    borderRadius: 8,
    paddingHorizontal: 8,
    width: 450
  },
  icon: {
    marginRight: 5,
  },
  containerTop: {
    width: '100%',
    flexDirection: 'row'
  },
  containerBtn: {
    width: 150,
    height: 50
  },
  btn:{
    height: 50,
    width: 150,
    backgroundColor: 'gray',
    borderColor: 'gray',
    borderWidth: 0.5,
    borderRadius: 8,
    marginLeft: 10
  },
  btnTitle: {
    marginHorizontal: 'auto',
    marginVertical: 'auto',
    fontSize: 17,
    color: 'white'
  },
  containerTable: {
    flex: 4,
    flexDirection: 'row',
    width: 600,
    borderBottomColor: 'grey',
    borderBottomWidth: 0.5
  },
  txtName: {
    width: 200
  },
  txtPrice: {
    width: 50
  },
  number: {
    width: 200
  },
  close:{
    width: 50
  },
  totalView: {
    marginTop: 30,
    flex: 1,
    justifyContent: 'flex-end'
  },
  totalViewText: {
    flex: 1,
    justifyContent: 'flex-end'
  }
});
